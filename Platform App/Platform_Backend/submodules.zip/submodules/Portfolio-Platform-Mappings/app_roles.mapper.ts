const app_rolesentityJson = {
    Id: "Id?",
    modified_by: "modified_by?",
    created_by: "created_by?",
    creation_date: "creation_date?",
    modified_date: "modified_date?",
    row_version: "row_version?",
    role_id: "role_id?",
    app_id: "app_id?",
    app_role_permissions: "app_role_permissions?"
};

const app_rolesdtoJson = {
    Id: "Id?",
    modified_by: "modified_by?",
    created_by: "created_by?",
    creation_date: "creation_date?",
    modified_date: "modified_date?",
    row_version: "row_version?",
    role_id: "role_id?",
    app_id: "app_id?",
    app_role_permissions: "app_role_permissions?"
};

const app_rolesentityToDtoJson = {
    Id: "Id?",
    modified_by: "modified_by?",
    created_by: "created_by?",
    creation_date: "creation_date?",
    modified_date: "modified_date?",
    row_version: "row_version?",
    role_id: "role_id?",
    app_id: "app_id?",
    app_role_permissions: "app_role_permissions?"
};

const app_rolesdtoToEntityJson = {
    Id: "Id?",
    modified_by: "modified_by?",
    created_by: "created_by?",
    creation_date: "creation_date?",
    modified_date: "modified_date?",
    row_version: "row_version?",
    role_id: "role_id?",
    app_id: "app_id?",
    app_role_permissions: "app_role_permissions?"
};

module.exports.app_rolesentityJson = app_rolesentityJson;
module.exports.app_rolesdtoJson = app_rolesdtoJson;
module.exports.app_rolesentityToDtoJson = app_rolesentityToDtoJson;
module.exports.app_rolesdtoToEntityJson = app_rolesdtoToEntityJson;