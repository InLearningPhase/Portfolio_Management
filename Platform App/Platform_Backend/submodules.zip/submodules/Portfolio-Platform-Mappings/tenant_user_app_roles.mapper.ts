const tenant_user_app_rolesentityJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_user_app_id: "tenant_user_app_id?",
  role_id: "role_id?",

};

const tenant_user_app_rolesdtoJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_user_app_id: "tenant_user_app_id?",
  role_id: "role_id?",
};

const tenant_user_app_rolesentityToDtoJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_user_app_id: "tenant_user_app_id?",
  role_id: "role_id?",
};

const tenant_user_app_rolesdtoToEntityJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_user_app_id: "tenant_user_app_id?",
  role_id: "role_id?",
};

module.exports.tenant_user_app_rolesentityJson = tenant_user_app_rolesentityJson;
module.exports.tenant_user_app_rolesdtoJson = tenant_user_app_rolesdtoJson;
module.exports.tenant_user_app_rolesentityToDtoJson = tenant_user_app_rolesentityToDtoJson;
module.exports.tenant_user_app_rolesdtoToEntityJson = tenant_user_app_rolesdtoToEntityJson;