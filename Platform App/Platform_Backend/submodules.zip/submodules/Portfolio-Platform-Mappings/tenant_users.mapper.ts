const tenant_usersentityJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_id: "tenant_id?",
  user_id: "user_id?",
  identity_provider_subscriber_id: "identity_provider_subscriber_id?",

};

const tenant_usersdtoJson = {

  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_id: "tenant_id?",
  user_id: "user_id?",
  identity_provider_subscriber_id: "identity_provider_subscriber_id?",
};

const tenant_usersentityToDtoJson = {

  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_id: "tenant_id?",
  user_id: "user_id?",
  identity_provider_subscriber_id: "identity_provider_subscriber_id?",
};

const tenant_usersdtoToEntityJson = {

  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_id: "tenant_id?",
  user_id: "user_id?",
  identity_provider_subscriber_id: "identity_provider_subscriber_id?",
};

module.exports.tenant_usersentityJson = tenant_usersentityJson;
module.exports.tenant_usersdtoJson = tenant_usersdtoJson;
module.exports.tenant_usersentityToDtoJson = tenant_usersentityToDtoJson;
module.exports.tenant_usersdtoToEntityJson = tenant_usersdtoToEntityJson;