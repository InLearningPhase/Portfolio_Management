const tenant_appsentityJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_id: "tenant_id?",
  app_id: "app_id?",
  connection_string: "connection_string?",
  all_features: "all_features?",

};

const tenant_appsdtoJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_id: "tenant_id?",
  app_id: "app_id?",
  connection_string: "connection_string?",
  all_features: "all_features?",

};

const tenant_appsentityToDtoJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_id: "tenant_id?",
  app_id: "app_id?",
  connection_string: "connection_string?",
  all_features: "all_features?",
};

const tenant_appsdtoToEntityJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  row_version: "row_version?",
  tenant_id: "tenant_id?",
  app_id: "app_id?",
  connection_string: "connection_string?",
  all_features: "all_features?",

};

module.exports.tenant_appsentityJson = tenant_appsentityJson;
module.exports.tenant_appsdtoJson = tenant_appsdtoJson;
module.exports.tenant_appsentityToDtoJson = tenant_appsentityToDtoJson;
module.exports.tenant_appsdtoToEntityJson = tenant_appsdtoToEntityJson;