import { Column, Entity, JoinColumn, ManyToOne, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { App } from "./apps.entity";
import { Role } from "./roles.entity";

@Entity('app_roles')
@Unique(["Id"])
export class App_Role extends EntityBase {
    
  @Column({ name: "role_id", nullable: false })
    role_id?: number;
  @Column({ name: "app_id", nullable: false })
    app_id?: number;
  @Column({ name: "app_role_permisssions" , nullable: false})
    app_role_permissions?: string;

    @ManyToOne(
      (type) => App,
      (apps) => apps.Id,
    )
    @JoinColumn({name: "app_id"})
    apps: App[];
    @ManyToOne(
      (type) => Role,
      (roles) => roles.Id,
    )
    @JoinColumn({name: "role_id"})
    roles: Role[];
}