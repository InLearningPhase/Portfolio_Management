
export class Guid{

    NewGuid(){
        return new Guid();
    }
}