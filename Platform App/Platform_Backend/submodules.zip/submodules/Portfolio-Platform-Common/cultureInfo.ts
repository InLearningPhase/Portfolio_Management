
export class CultureInfo{
    
}