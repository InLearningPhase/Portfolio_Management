import { Column, Entity, OneToMany, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Feature_Permission } from "./feature_permissions.entity";
import { Tenant } from "./tenants.entity";
import { Tenant_User } from "./tenant_users.entity";

@Entity('users')
@Unique(["Id"])
export class User extends EntityBase {
    
  @Column ({ name: "login_name" })
  login_name?: string;
  
  @Column ({ name: "birth_date" })
  birth_date?: Date;
  
  @Column ({ name: "date_of_joining" })
  date_of_joining?: Date;
    
    @Column ({ name: "first_name" })
    first_name?: string;
  
    @Column ({ name: "last_name" })
    last_name?: string;
  
    @Column ({ name: "email" })
    email?: string;
  
    @Column ({ name: "phone" })
    phone?: number;
  
    @Column ({ name: "marital_status" })
    marital_status?: string;

    @OneToMany(
      (type) => Tenant_User,
      (tenant_users) => tenant_users.users,
    )
    tenant_users: Tenant_User[];
    @OneToMany(
      (type) => Feature_Permission,
      (feature_permissions) => feature_permissions.users,
    )
    feature_permissions: Feature_Permission[];
   
}