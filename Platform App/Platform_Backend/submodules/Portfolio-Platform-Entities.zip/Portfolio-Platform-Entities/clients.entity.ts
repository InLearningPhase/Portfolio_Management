import { Column, Entity, OneToMany, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Tenant } from "./tenants.entity";

@Entity('clients')
@Unique(["Id"])
export class Client extends EntityBase {
 
    @Column ({ name: "address_id" })
    address_id?: number;
 
    @Column ({ name: "start_date" })
    start_date?: Date;
 
    @Column ({ name: "expiry_date" })
    expiry_date?: Date ;
 
    @Column ({ name: "client_key" })
    client_key?: string;
 
    @Column ({ name: "client_name" })
    client_name?: string;
 
    @Column ({ name: "description" })
    description?: string;
 
    @Column ({ name: "contact_id" })
    contact_id?: number;
    @OneToMany(
      (type) => Tenant,
      TenantsEntity => TenantsEntity.clients,
    )
    tenants: Tenant[]

}