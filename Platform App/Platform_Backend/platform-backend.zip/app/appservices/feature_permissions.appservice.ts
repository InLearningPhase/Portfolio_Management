import { HttpService, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Feature_PermissionsDto } from "../../submodules/Portfolio-Platform-Dtos/feature_permissions";
import { Feature_Permissions } from "../../submodules/Portfolio-Platform-Entities/feature_permissions";
import AppService from "../../submodules/Portfolio-Platform-Framework/AppServiceBase";
import { Repository } from "typeorm";
let dto = require('../../submodules/Portfolio-Platform-Mappings/feature_permissions.mapper')

@Injectable()
export default class Feature_PermissionsAppService extends AppService<Feature_Permissions,Feature_PermissionsDto>{
    constructor(@InjectRepository(Feature_Permissions) private readonly feature_permissionsRepository: Repository<Feature_Permissions>,public http:HttpService) {
        super(http,feature_permissionsRepository,Feature_Permissions,Feature_Permissions,Feature_PermissionsDto,dto.feature_permissionsentityJson, dto.feature_permissionsdtoJson,dto.feature_permissionsentityToDtoJson, dto.feature_permissionsdtoToEntityJson);
             
    }

} 