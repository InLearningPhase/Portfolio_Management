import { HttpService, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { ClientsDto } from "../../submodules/Portfolio-Platform-Dtos/clients";
import { Clients } from "../../submodules/Portfolio-Platform-Entities/clients";
import AppService from "../../submodules/Portfolio-Platform-Framework/AppServiceBase";
import { Repository } from "typeorm";
let dto = require('../../submodules/Portfolio-Platform-Mappings/clients.mapper')

@Injectable()
export default class ClientsAppService extends AppService<Clients,ClientsDto>{
    constructor(@InjectRepository(Clients) private readonly clientsRepository: Repository<Clients>,public http:HttpService) {
        super(http,clientsRepository,Clients,Clients,ClientsDto,dto.clientsentityJson, dto.clientsdtoJson,dto.clientsentityToDtoJson, dto.clientsdtoToEntityJson);
             
    }

} 