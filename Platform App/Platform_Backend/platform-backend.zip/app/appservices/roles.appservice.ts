import { HttpService, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { RolesDto } from "../../submodules/Portfolio-Platform-Dtos/roles";
import { Roles } from "../../submodules/Portfolio-Platform-Entities/roles";
import AppService from "../../submodules/Portfolio-Platform-Framework/AppServiceBase";
import { Repository } from "typeorm";
let dto = require('../../submodules/Portfolio-Platform-Mappings/roles.mapper')

@Injectable()
export default class RolesAppService extends AppService<Roles,RolesDto>{
    constructor(@InjectRepository(Roles) private readonly rolesRepository: Repository<Roles>,public http:HttpService) {
        super(http,rolesRepository,Roles,Roles,RolesDto,dto.rolesentityJson, dto.rolesdtoJson,dto.rolesentityToDtoJson, dto.rolesdtoToEntityJson);
             
    }
} 