import { HttpService, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { UsersDto } from "../../submodules/Portfolio-Platform-Dtos/users";
import { Users } from "../../submodules/Portfolio-Platform-Entities/users";
import AppService from "../../submodules/Portfolio-Platform-Framework/AppServiceBase";
import { Repository } from "typeorm";
let dto = require('../../submodules/Portfolio-Platform-Mappings/users.mapper')

@Injectable()
export default class UsersAppService extends AppService<Users,UsersDto>{
    constructor(@InjectRepository(Users) private readonly usersRepository: Repository<Users>,public http:HttpService) {
        super(http,usersRepository,Users,Users,UsersDto,dto.usersentityJson, dto.usersdtoJson,dto.usersentityToDtoJson, dto.usersdtoToEntityJson);
             
    }

} 