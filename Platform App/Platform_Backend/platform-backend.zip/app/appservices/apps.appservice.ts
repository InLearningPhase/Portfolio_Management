import { HttpService, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { AppsDto } from "../../submodules/Portfolio-Platform-Dtos/apps";
import { Apps } from "../../submodules/Portfolio-Platform-Entities/apps";
import AppService from "../../submodules/Portfolio-Platform-Framework/AppServiceBase";
import { Repository } from "typeorm";
let dto = require('../../submodules/Portfolio-Platform-Mappings/apps.mapper')

@Injectable()
export default class AppsAppService extends AppService<Apps,AppsDto>{
    constructor(@InjectRepository(Apps) private readonly appsRepository: Repository<Apps>,public http:HttpService) {
        super(http,appsRepository,Apps,Apps,AppsDto,dto.appsentityJson, dto.appsdtoJson,dto.appsentityToDtoJson, dto.appsdtoToEntityJson);
             
    }

} 