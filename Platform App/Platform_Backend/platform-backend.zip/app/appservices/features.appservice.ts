import { HttpService, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { FeaturesDto } from "../../submodules/Portfolio-Platform-Dtos/features";
import { Features } from "../../submodules/Portfolio-Platform-Entities/features";
import AppService from "../../submodules/Portfolio-Platform-Framework/AppServiceBase";
import { Repository } from "typeorm";
let dto = require('../../submodules/Portfolio-Platform-Mappings/features.mapper')

@Injectable()
export default class FeaturesAppService extends AppService<Features,FeaturesDto>{
    constructor(@InjectRepository(Features) private readonly featuresRepository: Repository<Features>,public http:HttpService) {
        super(http,featuresRepository,Features,Features,FeaturesDto,dto.featuresentityJson, dto.featuresdtoJson,dto.featuresentityToDtoJson, dto.featuresdtoToEntityJson);
             
    }

} 