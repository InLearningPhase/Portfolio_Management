import { HttpService, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { TenantsDto } from "../../submodules/Portfolio-Platform-Dtos/tenants";
import { Tenants } from "../../submodules/Portfolio-Platform-Entities/tenants";
import AppService from "../../submodules/Portfolio-Platform-Framework/AppServiceBase";
import { Repository } from "typeorm";
let dto = require('../../submodules/Portfolio-Platform-Mappings/tenants.mapper')

@Injectable()
export default class TenantsAppService extends AppService<Tenants,TenantsDto>{
    constructor(@InjectRepository(Tenants) private readonly tenantsRepository: Repository<Tenants>,public http:HttpService) {
        super(http,tenantsRepository,Tenants,Tenants,TenantsDto,dto.tenantsentityJson, dto.tenantsdtoJson,dto.tenantsentityToDtoJson, dto.tenantsdtoToEntityJson);
             
    }

} 