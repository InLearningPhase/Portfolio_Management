import { Injectable } from "@nestjs/common";
import TenantsAppService from "../appservices/tenants.appservice";
import { TenantsDto } from "../../submodules/Portfolio-Platform-Dtos/tenants";
import { Tenants } from "../../submodules/Portfolio-Platform-Entities/tenants";
import FacadeBase from "./facadebase";

@Injectable()
export class TenantsFacade extends FacadeBase<Tenants,TenantsDto>{
    constructor(private tenantsAppService: TenantsAppService){
       super(tenantsAppService);
    }
}