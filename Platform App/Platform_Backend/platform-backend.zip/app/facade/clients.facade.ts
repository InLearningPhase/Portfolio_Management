import { Injectable } from "@nestjs/common";
import ClientsAppService from "../appservices/clients.appservice";
import { ClientsDto } from "../../submodules/Portfolio-Platform-Dtos/clients";
import { Clients } from "../../submodules/Portfolio-Platform-Entities/clients";
import FacadeBase from "./facadebase";

@Injectable()
export class ClientsFacade extends FacadeBase<Clients,ClientsDto>{
    constructor(private clientsAppService: ClientsAppService){
       super(clientsAppService);
    }
}