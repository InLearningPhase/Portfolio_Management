import { Injectable } from "@nestjs/common";
import UsersAppService from "../appservices/users.appservice";
import { UsersDto } from "../../submodules/Portfolio-Platform-Dtos/users";
import { Users } from "../../submodules/Portfolio-Platform-Entities/users";
import FacadeBase from "./facadebase";

@Injectable()
export class UsersFacade extends FacadeBase<Users,UsersDto>{
    constructor(private usersAppService: UsersAppService){
       super(usersAppService);
    }
}