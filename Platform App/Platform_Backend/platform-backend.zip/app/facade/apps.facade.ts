import { Injectable } from "@nestjs/common";
import AppsAppService from "../appservices/apps.appservice";
import { AppsDto } from "../../submodules/Portfolio-Platform-Dtos/apps";
import { Apps } from "../../submodules/Portfolio-Platform-Entities/apps";
import FacadeBase from "./facadebase";

@Injectable()
export class AppsFacade extends FacadeBase<Apps,AppsDto>{
    constructor(private appsAppService: AppsAppService){
       super(appsAppService);
    }
}