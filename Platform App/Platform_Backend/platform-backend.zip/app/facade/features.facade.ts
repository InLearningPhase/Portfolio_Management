import { Injectable } from "@nestjs/common";
import FeaturesAppService from "../appservices/features.appservice";
import { FeaturesDto } from "../../submodules/Portfolio-Platform-Dtos/features";
import { Features } from "../../submodules/Portfolio-Platform-Entities/features";
import FacadeBase from "./facadebase";

@Injectable()
export class FeaturesFacade extends FacadeBase<Features,FeaturesDto>{
    constructor(private featuresAppService: FeaturesAppService){
       super(featuresAppService);
    }
}