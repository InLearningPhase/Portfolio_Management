
export enum ConditionalOperation{
    And = 1,
    Or = 2
}