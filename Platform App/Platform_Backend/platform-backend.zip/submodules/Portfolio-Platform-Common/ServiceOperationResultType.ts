

export enum ServiceOperationResultType{

     failure = 0,
     success = 1,
     error = 2

}
