const feature_permissionsentityJson = {
    Id: "Id?",
    modified_by: "modified_by?",
    created_by: "created_by?",
    creation_date: "creation_date?",
    modified_date: "modified_date?",
    rowversion: "rowversion?",
    feature_id: "feature_id?",
    operation_permitted: "operation_permitted",
    role_id: "role_id?",
    user_id: "user_id?",
    role_feature_security: "role_feature_security?"
};

const feature_permissionsdtoJson = {
    Id: "Id?",
    modified_by: "modified_by?",
    created_by: "created_by?",
    creation_date: "creation_date?",
    modified_date: "modified_date?",
    rowversion: "rowversion?",
    feature_id: "feature_id?",
    operation_permitted: "operation_permitted",
    role_id: "role_id?",
    user_id: "user_id?",
    role_feature_security: "role_feature_security?"
};

const feature_permissionsentityToDtoJson = {
    Id: "Id?",
    modified_by: "modified_by?",
    created_by: "created_by?",
    creation_date: "creation_date?",
    modified_date: "modified_date?",
    rowversion: "rowversion?",
    feature_id: "feature_id?",
    operation_permitted: "operation_permitted",
    role_id: "role_id?",
    user_id: "user_id?",
    role_feature_security: "role_feature_security?"
};

const feature_permissionsdtoToEntityJson = {
    Id: "Id?",
    modified_by: "modified_by?",
    created_by: "created_by?",
    creation_date: "creation_date?",
    modified_date: "modified_date?",
    rowversion: "rowversion?",
    feature_id: "feature_id?",
    operation_permitted: "operation_permitted",
    role_id: "role_id?",
    user_id: "user_id?",
    role_feature_security: "role_feature_security?"
};

module.exports.feature_permissionsentityJson = feature_permissionsentityJson;
module.exports.feature_permissionsdtoJson = feature_permissionsdtoJson;
module.exports.feature_permissionsentityToDtoJson = feature_permissionsentityToDtoJson;
module.exports.feature_permissionsdtoToEntityJson = feature_permissionsdtoToEntityJson;


