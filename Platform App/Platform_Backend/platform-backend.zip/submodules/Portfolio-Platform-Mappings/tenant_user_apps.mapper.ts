const tenant_user_appsentityJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  rowversion: "rowversion?",
  tenant_user_id: "tenant_user_id?",
  tenant_app_id: "tenant_app_id?",
  tenant_user_app_permissions: "tenant_user_app_permissions?",
};

const tenant_user_appsdtoJson = {
  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  rowversion: "rowversion?",
  tenant_user_id: "tenant_user_id?",
  tenant_app_id: "tenant_app_id?",
  tenant_user_app_permissions: "tenant_user_app_permissions?",
};

const tenant_user_appsentityToDtoJson = {

  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  rowversion: "rowversion?",
  tenant_user_id: "tenant_user_id?",
  tenant_app_id: "tenant_app_id?",
  tenant_user_app_permissions: "tenant_user_app_permissions?",
};

const tenant_user_appsdtoToEntityJson = {

  Id: "Id?",
  modified_by: "modified_by?",
  created_by: "created_by?",
  creation_date: "creation_date?",
  modified_date: "modified_date?",
  rowversion: "rowversion?",
  tenant_user_id: "tenant_user_id?",
  tenant_app_id: "tenant_app_id?",
  tenant_user_app_permissions: "tenant_user_app_permissions?",
};

module.exports.tenant_user_appsentityJson = tenant_user_appsentityJson;
module.exports.tenant_user_appsdtoJson = tenant_user_appsdtoJson;
module.exports.tenant_user_appsentityToDtoJson = tenant_user_appsentityToDtoJson;
module.exports.tenant_user_appsdtoToEntityJson = tenant_user_appsdtoToEntityJson;