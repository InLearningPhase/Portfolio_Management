import { Column, Entity, ManyToOne, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Features } from "./features";
import { Roles } from "./roles";
import { Users } from "./users";

@Entity('feature_permission')

export class Feature_Permissions extends EntityBase {
    
    @Column ({ name: "feature_id", nullable: true })
    feature_id?: number;
 
    @Column ({ name: "operation_permitted", nullable: true, type: "json" })
    operation_permitted?: JSON;
 
    @Column ({ name: "role_id", nullable: true })
    role_id?: number;
 
    @Column ({ name: "user_id", nullable: true })
    user_id?: number;
 
    @Column ({ name: "role_feature_security", nullable: true, type: "json" })
    role_feature_security? : JSON;
    @ManyToOne(
      (type) => Features,
      (features) => features.feature_permissions,
    )
    features: Features[];
    @ManyToOne(
      (type) => Roles,
      (roles) => roles.feature_permissions,
    )
    roles: Roles[];
    @ManyToOne(
      (type) => Users,
      (users) => users.feature_permissions,
    )
    users: Users[];
}