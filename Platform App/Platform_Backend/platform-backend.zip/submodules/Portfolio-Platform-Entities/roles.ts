import { Column, Entity, OneToMany, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { App_Roles } from "./app_roles";
import { Feature_Permissions } from "./feature_permissions";
import { Tenant_User_App_Roles } from "./tenant_user_app_roles";

@Entity('roles')
@Unique(["Id"])
export class Roles extends EntityBase {
    
    @Column ({ name: "role_name", nullable: true })
    role_name?: string;
 
    @Column ({ name: "role_priviledge", nullable: true , type: "json"})
    role_priviledge?: JSON;
    @OneToMany(
      (type) => Feature_Permissions,
      (feature_permissions) => feature_permissions.role_id,
    )
    feature_permissions: Feature_Permissions [];
    @OneToMany(
      (type) => App_Roles,
      (app_roles) => app_roles.app_id,
    )
    app_roles: App_Roles[];
    @OneToMany(
      (type) => Tenant_User_App_Roles,
      (tenant_user_app_roles) => tenant_user_app_roles.role_id,
    )
    tenant_user_app_roles: Tenant_User_App_Roles[];
}