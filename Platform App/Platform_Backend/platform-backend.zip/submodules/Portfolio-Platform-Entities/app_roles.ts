import { Column, Entity, ManyToOne, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Apps } from "./apps";
import { Roles } from "./roles";

@Entity('app_roles')
@Unique(["Id"])
export class App_Roles extends EntityBase {
    
  @Column({ name: "role_id", nullable: true })
    role_id?: number;
  @Column({ name: "app_id", nullable: true })
    app_id?: number;
  @Column({ name: "app_role_permisssions", nullable: true })
    app_role_permissions?: string;

    @ManyToOne(
      (type) => Apps,
      (apps) => apps.app_roles,
    )
    apps: Apps[];
    @ManyToOne(
      (type) => Roles,
      (roles) => roles.app_roles,
    )
    roles: Roles[];
}