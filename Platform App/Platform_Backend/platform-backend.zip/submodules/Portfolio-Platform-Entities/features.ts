import { Column, Entity, ManyToOne, OneToMany, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Apps } from "./apps";
import { Feature_Permissions } from "./feature_permissions";
import { Tenant_App_Features } from "./tenant_app_features";

@Entity('features')
@Unique(["Id"])
export class Features extends EntityBase {
    
    @Column ({ name: "feature_id", nullable: true })
    feature_id?: number;
 
    @Column ({ name: "feature_name", nullable: true })
    feature_name?: string;
 
    @Column ({ name: "app_id", nullable: true })
    app_id?: number;
 
    @Column ({ name: "base_feature_id", nullable: true })
    base_feature_id?: number;
 
    @Column ({ name: "feature_description", nullable: true })
    feature_description? : string;
 
    @Column ({ name: "feature_key", nullable: true })
    feature_key? : string;
 
    @Column ({ name: "operations", nullable: true })
    operations? :string;
 
    @Column ({ name: "feature_type", nullable: true })
    feature_type? : number;
    
    @ManyToOne(
      (type) => Apps,
      (apps) => apps.features,
    )
    apps: Apps[];
    @OneToMany(
      (type) => Feature_Permissions,
      (feature_permissions) => feature_permissions.feature_id,
    )
    feature_permissions: Feature_Permissions[]
    @OneToMany(
      (type) => Feature_Permissions,
      (tenant_app_feature) => tenant_app_feature.feature_id,
    )
    tenant_app_features: Tenant_App_Features[]

}