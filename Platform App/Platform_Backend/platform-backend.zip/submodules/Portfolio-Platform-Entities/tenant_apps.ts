import { Column, Entity, ManyToOne, OneToMany, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Apps } from "./apps";
import { Tenants } from "./tenants";
import { Tenant_App_Features } from "./tenant_app_features";
import { Tenant_User_Apps } from "./tenant_user_apps";

@Entity('tenant_apps')
@Unique(["Id"])
export class Tenant_Apps extends EntityBase {
  
  
  @Column ({ name: "tenant_id", nullable: true })
  tenant_id?: number;
  
  @Column ({ name: "app_id", nullable: true })
  app_id?: number;
  
  @Column ({ name: "connection_string", nullable: true })
  connection_string?: string;
  
  @Column ({ name: "all_features", nullable: true })
  all_features : boolean=false;
  @ManyToOne(
    (type) => Apps,
    (apps) => apps.tenant_apps,
  )
  apps: Apps[];
  @ManyToOne(
    (type) => Tenants,
    (tenants) => tenants.tenant_apps,
  )
  tenants: Tenants[];
  @OneToMany(
    (type) => Tenant_App_Features,
    (tenant_app_features) => tenant_app_features.tenant_app_id,
  )
  tenant_app_features: Tenant_App_Features[];
  @OneToMany(
    (type) => Tenant_User_Apps,
    (tenant_user_apps) => tenant_user_apps.tenant_app_id,
  )
  tenant_user_apps: Tenant_User_Apps[];
}