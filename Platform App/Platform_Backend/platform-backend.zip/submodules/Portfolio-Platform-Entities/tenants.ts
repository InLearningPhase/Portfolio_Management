import { Column, Entity, JoinColumn, ManyToOne, OneToMany, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Clients } from "./clients";
import { Tenant_Apps } from "./tenant_apps";
import { Tenant_Users } from "./tenant_users";
@Entity('tenants')
@Unique(["Id"])
export class Tenants extends EntityBase {
    
    
  @Column ({ name: "tanant_name", nullable: true })
  tenant_name?: string;
  
  @Column ({ name: "description", nullable: true })
  description?: string;
  
  @Column ({ name: "alias", nullable: true })
  alias?: string;
  
  @Column ({ name: "published_from", nullable: true })
  published_from?: Date;
  
  @Column ({ name: "published_till", nullable: true })
  published_till?: Date;
  
  @Column ({ name: "is_complete", nullable: true })
  is_complete?: boolean;
  
  @Column ({ name: "site_image_url_path", nullable: true })
  site_image_url_path?: string;
  
  @Column ({ name: "status_id", nullable: true })
  status_id?: number;
  
  @Column ({ name: "client_Id", nullable: true })
  client_Id?: number;
  
  @Column ({ name: "identity_providers_details", nullable: true , type: "json"})
  identity_providers_details?: JSON;
  
  @Column ({ name: "tenant_admin_email", nullable: true })
  tenant_admin_email?: string;

  @OneToMany(
    (type) => Tenant_Users,
    (tenant_users) => tenant_users.tenant_id,
  )
  tenant_users: Tenant_Users[];
  @OneToMany(
    (type) => Tenant_Apps,
    (tenant_apps) => tenant_apps.tenant_id,
  )
  tenant_apps: Tenant_Apps[];
  
  @ManyToOne(
    (type) => Clients,
    (ClientsEntity) => ClientsEntity.Id,
  )
  @JoinColumn({name: "client_Id"})
  clients: Clients;
}