import { Column, Entity, ManyToOne, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Features } from "./features";
import { Tenant_Apps } from "./tenant_apps";

@Entity('tenant_app_features')
@Unique(["Id"])
export class Tenant_App_Features extends EntityBase {
  
  @Column ({ name: "tenant_app_id", nullable: true })
  tenant_app_id?: number;
 
  @Column ({ name: "feature_id", nullable: true })
  feature_id?: number;
  @ManyToOne(
    (type) => Features,
    (features) => features.tenant_app_features,
  )
  features: Features[];
  @ManyToOne(
    (type) => Features,
    (tenant_apps) => tenant_apps.tenant_app_features,
  )
  tenant_apps: Tenant_Apps[];
}