import { Column, Entity, ManyToOne, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Roles } from "./roles";
import { Tenant_User_Apps } from "./tenant_user_apps";
@Entity('tenant_user_app_roles')
@Unique(["Id"])
export class Tenant_User_App_Roles extends EntityBase {
  
  @Column ({ name: "tenant_user_app_id", nullable: true })
  tenant_user_app_id?: number;
 
  @Column ({ name: "role_id", nullable: true })
  role_id?: number;
  @ManyToOne(
    (type) => Roles,
    (roles) => roles.tenant_user_app_roles,
  )
  roles: Roles[];
  @ManyToOne(
    (type) => Tenant_User_Apps,
    (tenant_user_apps) => tenant_user_apps.tenant_user_app_roles,
  )
  tenant_user_apps: Tenant_User_Apps[];

}