import { Column, Entity, ManyToOne, OneToMany, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Tenants } from "./tenants";
import { Tenant_User_Apps } from "./tenant_user_apps";
import { Users } from "./users";
@Entity('tenant_users')
@Unique(["Id"])
export class Tenant_Users extends EntityBase {
    
  @Column ({ name: "tenant_id", nullable: true })
  tenant_id?: number;
  
  @Column ({ name: "user_id", nullable: true })
  user_id?: number;
  
  @Column ({ name: "identity_provider_subscriber_id", nullable: true })
  identity_provider_subscriber_id?: string;
  @ManyToOne(
    (type) => Users,
    (users) => users.tenant_users,
  )
  users: Users[];
  @ManyToOne(
    (type) => Tenants,
    (tenants) => tenants.tenant_users,
  )
  tenants: Tenants[];
  @OneToMany(
    (type) => Tenant_User_Apps,
    (tenant_user_apps) => tenant_user_apps.tenant_user_id,
  )
  tenant_user_apps: Tenant_User_Apps[];
}