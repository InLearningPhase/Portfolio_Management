
import { Column, Entity, OneToMany, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { App_Messages } from "./app_messages";
import { App_Roles } from "./app_roles";
import { Features } from "./features";
import { Tenant_Apps } from "./tenant_apps";

@Entity('apps')
@Unique(["Id"])
export class Apps extends EntityBase {
    
  @Column ({ name: "app_name", nullable: true })
    app_name?: string;
    
  @Column({ name: "app_description", nullable: true })
    app_description?: string;


    @OneToMany(
      (type) => App_Messages,
      (app_message) => app_message.app_id,
    )
    app_message: App_Messages[];
    @OneToMany(
      (type) => Features,
      (features) => features.app_id,
    )
    features: Features[];
    @OneToMany(
      (type) => App_Roles,
      (app_roles) => app_roles.app_id,
    )
    app_roles: App_Roles[];
    @OneToMany(
      (type) => Tenant_Apps,
      (tenant_apps) => tenant_apps.app_id,
    )
    tenant_apps: Tenant_Apps[];
}