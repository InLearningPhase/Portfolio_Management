import { Column, Entity, OneToMany, Unique } from "typeorm";
import { EntityBase } from "./EntityBase/entitybase";
import { Feature_Permissions } from "./feature_permissions";
import { Tenants } from "./tenants";
import { Tenant_Users } from "./tenant_users";

@Entity('users')
@Unique(["Id"])
export class Users extends EntityBase {
    
  @Column ({ name: "login_name", nullable: true })
  login_name?: string;
  
  @Column ({ name: "birth_date", nullable: true })
  birth_date?: Date;
  
  @Column ({ name: "date_of_joining", nullable: true })
  date_of_joining?: Date;
    
    @Column ({ name: "first_name", nullable: true })
    first_name?: string;
  
    @Column ({ name: "last_name", nullable: true })
    last_name?: string;
  
    @Column ({ name: "email", nullable: true })
    email?: string;
  
    @Column ({ name: "phone", nullable: true })
    phone?: number;
  
    @Column ({ name: "marital_status", nullable: true })
    marital_status?: string;

    @OneToMany(
      (type) => Tenant_Users,
      (tenant_users) => tenant_users.user_id,
    )
    tenant_users: Tenant_Users[];
    @OneToMany(
      (type) => Feature_Permissions,
      (feature_permissions) => feature_permissions.user_id,
    )
    feature_permissions: Feature_Permissions[];
   
}